const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Нормализовать image_url: если только имя файла — добавить путь
function normalizeBannerImageUrl(banner) {
  const url = banner.image_url || '';
  if (!url) return banner;
  if (url.startsWith('/') || url.startsWith('http')) return banner;
  return { ...banner, image_url: `/uploads/banners/${url}` };
}

// Получить все активные баннеры
router.get('/', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    const [banners] = await db.query(
      'SELECT * FROM banners WHERE is_active = TRUE ORDER BY sort_order ASC'
    );
    res.json(banners.map(normalizeBannerImageUrl));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

