const IS_PROD = process.env.NODE_ENV === 'production';

export const BASE_URL = IS_PROD
    ? ''
    : 'http://localhost:5001';

const API_URL = `${BASE_URL}/api`;

export default API_URL;
